import static org.junit.jupiter.api.Assertions.*;

class EvenTesterTest {

    @org.junit.jupiter.api.Test
    void isEven() {
        EvenTester e = new EvenTester();

        // Test ID: E1
        // Name: EvenTrue
        // Preconditions: An object from class EvenTester must exist
        // Steps: Check isEven for an even number
        // Data: 4
        // Expected result: true
        assertEquals(true, e.isEven(4));

        // Test ID: E2
        // Name: EvenFalse
        // Preconditions: An object from class EvenTester must exist
        // Steps: Check isEven for an odd number
        // Data: 5
        // Expected result: false
        assertEquals(false, e.isEven(5));
    }
}