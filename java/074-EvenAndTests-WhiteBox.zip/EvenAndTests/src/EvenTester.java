public class EvenTester {

    public boolean isEven(int n) {
        return n % 2 == 0;
    }
}
