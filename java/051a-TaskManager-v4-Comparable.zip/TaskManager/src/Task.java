public class Task implements Comparable<Task> {
    protected String description;
    protected byte priority;

    public Task(String description, byte priority) {
        this.description = description;
        this.priority = priority;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public byte getPriority() {
        return priority;
    }

    public void setPriority(byte priority) {
        this.priority = priority;
    }

    @Override
    public String toString() {
        return description + " (" + priority +")";
    }

    @Override
    public int compareTo(Task o) {
        return -1 * (this.priority - o.priority);
    }
}
