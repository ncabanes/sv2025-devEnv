void main() {
    Author a = new Author();
    a.Test();
}
