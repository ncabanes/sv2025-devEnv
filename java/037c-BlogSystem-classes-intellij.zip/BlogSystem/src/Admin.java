public class Admin extends User {
    // Attributes
    // ...

    // Methods
    public void RegisterUser() {
        // ...
    }
}
