public class User {

    // Attributes
    protected String login;
    protected String password;

    // Methods
    // ...
}
