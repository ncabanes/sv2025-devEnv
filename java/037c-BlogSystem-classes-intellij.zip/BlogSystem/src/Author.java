public class Author extends Editor {
    // Attributes
    // ...

    // Methods
    public void CreatePost() {
        // ...
    }

    public void Test() {
        login = "author001";
        CreatePost();
        PublishPost();
    }
}
