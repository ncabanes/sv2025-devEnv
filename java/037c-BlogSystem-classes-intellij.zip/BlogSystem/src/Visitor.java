public class Visitor extends User {
    // Attributes
    // ...

    // Methods
    public void CommentPost() {
        // ...
    }
}