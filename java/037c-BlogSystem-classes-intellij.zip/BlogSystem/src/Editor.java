public class Editor extends User {
    // Attributes
    // ...

    // Methods
    public void PublishPost() {
        // ...
    }
}