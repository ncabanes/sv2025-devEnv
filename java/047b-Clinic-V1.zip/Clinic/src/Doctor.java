public class Doctor extends Person {

    protected String specialty;

    public Doctor(String name, int code, String specialty) {
        super(name, code);
        this.specialty = specialty;
    }

    public Doctor(String name, int code) {
        super(name, code);
        this.specialty = "General Medicine";
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    @Override
    public String toString() {
        return super.toString() + ", " + specialty;
    }

}
