import java.util.Scanner;

public class Clinic {

    Scanner sc = new Scanner(System.in);

    public void run() {

        Doctor d1 = new Doctor( "Jordan, Michael", 1, "Sports");
        Doctor d2 = new Doctor( "Ewing, Patrick", 2);
        Nurse n1 = new Nurse( "Stockton, John", 3);
        Patient[] patients = new Patient[1000];
        int amountOfPatients = 0;
        boolean finished = false;

        do {
            System.out.println("1- Add a patient");
            System.out.println("2- Search patients");
            System.out.println("0- Exit");

            String option = sc.nextLine();
            switch (option) {
                case "1": amountOfPatients = addPatient(patients, amountOfPatients); break;
                case "2": searchPatient(patients, amountOfPatients); break;
                case "0": finished = true; break;
            }
        }
        while (! finished);

    }

    private int addPatient(Patient[] patients, int amount) {
        System.out.print("Enter the name: ");
        String name = sc.nextLine();
        System.out.print("Enter the code: ");
        int id = Integer.parseInt(sc.nextLine());
        Patient p = new Patient(name, id);
        patients[amount] = p;
        return amount + 1;
    }

    private void searchPatient(Patient[] patients, int amount) {
        System.out.print("Enter the search pattern: ");
        String search = sc.nextLine();
        for (int i = 0; i < amount; i++) {
            if(patients[i].name.contains(search)) {
                System.out.println(patients[i]);
            }
        }
    }

    public static void main() {
        Clinic c = new Clinic();
        c.run();
    }
}