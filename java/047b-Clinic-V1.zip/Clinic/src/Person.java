public abstract class Person implements Comparable<Person> {
    protected String name;
    protected int code;

    public Person(String name, int code) {
        this.name = name;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return code + ", " + name;
    }

    @Override
    public int compareTo(Person o) {
        return name.compareToIgnoreCase(o.name);
    }
}
