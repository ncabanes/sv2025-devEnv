public class Patient extends Person {
    public Patient(String name, int code) {
        super(name, code);
    }
}
