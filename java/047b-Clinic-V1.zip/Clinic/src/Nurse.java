public class Nurse extends Person {
    public Nurse(String name, int code) {
        super(name, code);
    }
}
