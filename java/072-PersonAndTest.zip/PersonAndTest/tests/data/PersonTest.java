package data;

import static org.junit.jupiter.api.Assertions.*;

class PersonTest {

    @org.junit.jupiter.api.Test
    void getName() {
        Person juan = new Person("Juan", 25);
        assertEquals("Juan", juan.getName());
    }

    @org.junit.jupiter.api.Test
    void setName() {
        Person juan = new Person("Juan", 25);
        juan.setName("Juan José");
        assertEquals("Juan José", juan.getName());
    }

    @org.junit.jupiter.api.Test
    void getAge() {
        Person p = new Person("Juan", 25);
        assertEquals(25, p.getAge());
        assertNotEquals(0, p.getAge());
    }
}