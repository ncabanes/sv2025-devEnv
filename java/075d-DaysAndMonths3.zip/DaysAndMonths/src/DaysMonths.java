public class DaysMonths {
    // Third version, more compact
    int getDaysLeft(int dayOfMonth, int monthNumber) {
        int daysRemaining;
        byte[] daysInMonth = {31,28,31,30,31,30,
            31,31,30,31,30,31};
        if ((dayOfMonth >= 1) && (dayOfMonth <= 31)
                && (monthNumber >= 1) && (monthNumber <=12)
                && (dayOfMonth <= daysInMonth[monthNumber-1])) {
            daysRemaining = daysInMonth[monthNumber-1] - dayOfMonth;
        }
        else
            daysRemaining = -1;
        return daysRemaining;
    }
}
