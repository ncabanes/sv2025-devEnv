/**
 * Class Task: A single task to be managed
 */
public class Task  {
    protected String description;
    protected byte priority;

    public Task(String description, byte priority) {
        this.description = description;
        this.priority = priority;
    }

    /**
     * Returns the description for this task
     * @return The description (string)
     */
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public byte getPriority() {
        return priority;
    }

    public void setPriority(byte priority) {
        this.priority = priority;
    }

    @Override
    public String toString() {
        return description + " (" + priority +")";
    }
}
