public class MediaTest {
    public static void main() {
        Image i = new Image("(unknown)", 3200, "JPG", 2304, 1536);
        Sound s = new Sound("Hector Berlioz", 37000, "MP3", true, 192, 340);
        Video v = new Video("Akira Kurosawa", 1320000, "MP4", "H264", 1920, 100, 4010 );

        System.out.println(i);
        System.out.println(s);
        System.out.println(v);

        Media[] media = new Media[2];
        media[0] = new Image("Pablo Picasso", 4700, "JPG", 3000, 4000);
        media[1] =  new Sound("Richard Wagner", 33000, "MP3", true, 240, 405);

        System.out.println();

        for (Media m : media) {
            System.out.println(m.getType() + ": " + m);
        }
    }
}