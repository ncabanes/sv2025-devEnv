public class DaysMonths {
    // First version, too many "return"
    int getDaysLeft(int dayOfMonth, int monthNumber) {
        if ((dayOfMonth > 31) || (dayOfMonth < 1))
            return -1;
        if ((monthNumber > 12) || (monthNumber < 1))
            return -1;
        if ((dayOfMonth > 30) && ((monthNumber == 4)
                || (monthNumber == 6) || (monthNumber == 9) || (monthNumber == 11)))
            return -1;
        if ((dayOfMonth > 28) && (monthNumber == 2))
            return -1;

        switch (monthNumber) {
            case 2:
                return 28 - dayOfMonth;
            case 4:
            case 6:
            case 9:
            case 11:
                return 30 - dayOfMonth;
            default:
                return 31 - dayOfMonth;
        }
    }
}
