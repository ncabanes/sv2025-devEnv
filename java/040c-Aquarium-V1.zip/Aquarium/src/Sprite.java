public class Sprite {
    protected int x;
    protected int y;

    public void animar() {
        // ...
    }

    public void dibujar() {
        // ...
    }
}
