public class Planta extends Sprite {
}
