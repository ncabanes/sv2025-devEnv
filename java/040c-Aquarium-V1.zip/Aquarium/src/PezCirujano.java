public class PezCirujano extends Pez {
}
