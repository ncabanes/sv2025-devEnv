public class PezBetta extends Pez {
}
