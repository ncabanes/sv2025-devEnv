public class Pez extends Sprite {
    private String color;

}
