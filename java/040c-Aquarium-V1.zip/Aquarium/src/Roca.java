public class Roca extends Sprite {
}
