public class PezPayaso extends Pez {
}
