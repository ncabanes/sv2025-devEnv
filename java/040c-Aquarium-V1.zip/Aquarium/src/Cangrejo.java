public class Cangrejo extends Sprite {
    private void Cazar() {
        // ...
    }
}
