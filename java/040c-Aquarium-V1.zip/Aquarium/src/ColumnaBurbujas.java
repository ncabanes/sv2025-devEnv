public class ColumnaBurbujas extends Sprite {
}
