import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DaysMonthsTest {

    @Test
    void getDaysLeft() {
        DaysMonths dm = new DaysMonths();
        // Test: DL1
        assertEquals(-1, dm.getDaysLeft(20, -1));
        // Test: DL2
        assertEquals(-1, dm.getDaysLeft(20, 13));
        // Test: M30R
        assertEquals(15, dm.getDaysLeft(15, 4));
    }

}