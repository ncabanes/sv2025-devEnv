public class DaysMonths {
    // Second version, one "return" but too complicated
    int getDaysLeft(int dayOfMonth, int monthNumber) {
        int daysRemaining = -1;
        if ((dayOfMonth > 31) || (dayOfMonth < 1))
            daysRemaining = -1;
        else if ((monthNumber > 12) || (monthNumber < 1))
            daysRemaining = -1;
        else if ((dayOfMonth > 30) && ((monthNumber == 4)
                || (monthNumber == 6) || (monthNumber == 9) || (monthNumber == 11)))
            daysRemaining = -1;
        else if ((dayOfMonth > 28) && (monthNumber == 2))
            daysRemaining = -1;

        else switch (monthNumber) {
            case 2:
                daysRemaining = 28 - dayOfMonth;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                daysRemaining = 30 - dayOfMonth;
                break;
            default:
                daysRemaining = 31 - dayOfMonth;
                break;
        }
        return daysRemaining;
    }
}
