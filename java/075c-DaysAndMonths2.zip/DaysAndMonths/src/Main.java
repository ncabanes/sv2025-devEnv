
void main() {
    System.out.println("Days and months");
}
