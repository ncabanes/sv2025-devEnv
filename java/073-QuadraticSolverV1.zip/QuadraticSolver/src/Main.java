import java.util.List;

public class Main {
    public static void main(String[] args) {
        QuadraticSolver q = new QuadraticSolver();

        // x2 - 1 = 0
        List<Double> solutions = q.solveQuadratic(1,0,-1);
        for(double d: solutions)
            System.out.println(d);
    }
}