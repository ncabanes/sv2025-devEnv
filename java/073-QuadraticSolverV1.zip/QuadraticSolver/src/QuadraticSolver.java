import java.util.*;

public class QuadraticSolver {

    // TODO: Needs fixing
    List<Double> solveQuadratic(double a, double b, double c) {
        List<Double> solutions = new ArrayList<>();

        double discriminant = b*b - 4*a*c;
        if (discriminant == 0) // One solution
        {
            solutions.add(-b / 2 * a);
        }
        else if (discriminant > 0) // Two solutions
        {
            solutions.add(-b + Math.sqrt(b*b - 4*a*c) / 2*a);
            solutions.add(-b - Math.sqrt(b*b - 4*a*c) / 2*a);
        }
        return solutions;
    }

}
