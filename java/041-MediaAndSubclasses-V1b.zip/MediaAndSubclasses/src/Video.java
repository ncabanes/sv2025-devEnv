public class Video extends Media {
    private String codec;
    private int width;
    private int height;
    private float duration;

    public Video(String author, double size, String format, String codec, int width, int height, float duration) {
        // To be completed...
        this.codec = codec;
        this.width = width;
        this.height = height;
        this.duration = duration;
    }

    public String getCodec() { return codec; }
    public void setCodec(String codec) { this.codec = codec;}

    public int getWidth() { return width; }
    public void setWidth(int width) { this.width = width; }

    public int getHeight() { return height; }
    public void setHeight(int height) { this.height = height;}

    public float getDuration() { return duration; }
    public void setDuration(float duration) { this.duration = duration; }

    @Override
    public String toString() {
        return getAuthor() + " " + getSize() + "Kb. " + getFormat() +
            " Codec: " + codec +  " W: " + width + " H:" + height +
            " Secs:" + duration;
    }
}
