public class Sound extends Media {
    private boolean stereo;
    private int kbps;
    private float duration;

    public Sound(String author, double size, String format, boolean stereo, int kbps, float duration) {
        // To be completed...
        this.stereo = stereo;
        this.kbps = kbps;
        this.duration = duration;
    }

    public boolean isStereo() { return stereo; }
    public void setStereo(boolean stereo) { this.stereo = stereo; }

    public int getKbps() { return kbps; }
    public void setKbps(int kbps) { this.kbps = kbps; }

    public float getDuration() { return duration; }
    public void setDuration(float duration) { this.duration = duration; }

    @Override
    public String toString() {
        return getAuthor() + " " + getSize() + "Kb. " + getFormat() +
                " St: " + stereo + " Kbps:" + kbps + " Secs:" + duration;
    }
}
