public class Image extends Media {
    private int width;
    private int height;

    public Image(String author, double size, String format, int width, int height) {
        // To be completed...
        this.width = width;
        this.height = height;
    }

    public int getWidth() { return width; }
    public void setWidth(int width) { this.width = width; }

    public int getHeight() { return height; }
    public void setHeight(int height) { this.height = height;}

    @Override
    public String toString() {
        return getAuthor() + " " + getSize() + "Kb. " + getFormat() +
                " W: " + width + " H:" + height;
    }
}
