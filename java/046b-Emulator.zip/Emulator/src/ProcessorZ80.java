public class ProcessorZ80 extends Processor {
    public ProcessorZ80(float mhz) {
        super(8, mhz, "A B C D E F H L");
    }

    public void ShowCommands() {
        System.out.print("Z80: ");
        super.ShowCommands();
    }

    @Override
    public String toString() {
        return "Z80, " + super.toString();
    }
}
