public class Processor6502 extends Processor {
    public Processor6502(float mhz) {
        super(8, mhz, "A X Y");
    }

    public void ShowCommands() {
        System.out.print("6502: ");
        super.ShowCommands();
    }

    @Override
    public String toString() {
        return "6502, " + super.toString();
    }
}
