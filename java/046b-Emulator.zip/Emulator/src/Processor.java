public abstract class Processor {
    protected int bits;
    protected float mhz;
    protected String registers;

    public Processor(int bits, float mhz, String registers) {
        this.bits = bits;
        this.mhz = mhz;
        this.registers = registers;
    }

    public int getBits() {
        return bits;
    }

    public float getMhz() {
        return mhz;
    }

    @Override
    public String toString() {
        return bits +
                "bits, " + mhz +
                " MHz";
    }

    public void AddCommand(int numericCode, String assembler) {
    }

    public void ShowCommands() {
        System.out.println("List of commands not yet available");
    }
}
