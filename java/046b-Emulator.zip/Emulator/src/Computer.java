public class Computer {

    protected Processor processor;
    protected Memory memory;
    protected String name;

    public Computer(Processor processor, Memory memory, String name) {
        this.processor = processor;
        this.memory = memory;
        this.name = name;
    }

    public Processor getProcessor() {
        return processor;
    }

    public void setProcessor(Processor processor) {
        this.processor = processor;
    }

    public Memory getMemory() {
        return memory;
    }

    public void setMemory(Memory memory) {
        this.memory = memory;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name + ", " +
            processor.toString() + ", " +
            memory.getSize() + " bytes of memory";
    }
}
