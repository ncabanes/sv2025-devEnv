import java.util.Scanner;

public class Emulators {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        final int MAX = 300;
        Computer[] computers = new Computer[MAX];

        computers[0] = new Computer(
                new ProcessorZ80(3.5f),
                new Memory(16384),
                "ZX Spectrum"
        );
        computers[1] = new Computer(
                new Processor6502(1.1f),
                new Memory(5120),
                "Commodore VIC-20"
        );
        int amount = 2;

        boolean finished = false;
        do {
            System.out.println("1 - Add a Z80-based computer");
            System.out.println("2 - Add a 6502-based computer");
            System.out.println("3 - View all computers");
            System.out.println("0 - Exit");

            String option = sc.nextLine();
            String name, mhzStr, bytesStr;
            switch(option) {
                case "1":
                    System.out.println("Adding a Z80-base computer");
                    System.out.print("Name? ");
                    name = sc.nextLine();
                    System.out.print("MHz? ");
                    mhzStr = sc.nextLine();
                    System.out.print("Bytes of RAM? ");
                    bytesStr = sc.nextLine();
                    try {
                        computers[amount] = new Computer(
                                new ProcessorZ80(Float.parseFloat(mhzStr)),
                                new Memory(Integer.parseInt(bytesStr)),
                                name
                        );
                        amount++;
                    } catch (Exception e) {
                        System.out.println("Ooops! " + e.getMessage());;
                    }
                    break;
                case "2":
                    System.out.println("Adding a 6502-base computer");
                    System.out.print("Name? ");
                    name = sc.nextLine();
                    System.out.print("MHz? ");
                    mhzStr = sc.nextLine();
                    System.out.print("Bytes of RAM? ");
                    bytesStr = sc.nextLine();
                    try {
                        computers[amount] = new Computer(
                                new Processor6502(Float.parseFloat(mhzStr)),
                                new Memory(Integer.parseInt(bytesStr)),
                                name
                        );
                        amount++;
                    } catch (Exception e) {
                        System.out.println("Ooops! " + e.getMessage());;
                    }
                    break;
                case"3":
                    for (int i = 0; i < amount; i++)
                        System.out.println(computers[i]);
                    break;
                case "0":
                    finished = true;
                    break;
            }

        }
        while (! finished);
    }
}