public interface IAddressable {
    public byte getAddress(int pos);
    public void set(int address, byte value);
}
