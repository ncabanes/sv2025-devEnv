public class Memory implements  IAddressable {

    protected int size;
    protected byte[] data;

    public Memory(int size) {
        this.size = size;
        data = new byte[size];
    }

    public Memory(int size,int dataBus) {
        this(size);
        // TODO: implement data bus size
    }

    public int getSize() {
        return size;
    }

    public byte getAddress(int pos) {
        return data[pos];
    }

    public void set(int address, byte value) {
        data[address] = value;
    }
}
