public class Media {

    protected String author;
    protected double size;
    protected String format;

    public Media(String author, double size, String format) {
        this.author = author;
        this.size = size;
        this.format = format;
    }

    public Media(double size, String format) {
        this("(Unknown)", size, format);
    }

    public String getAuthor() {
        return author;
    }
    public void setAuthor(String author) {
        this.author = author;
    }

    public double getSize() {
        return size;
    }
    public void setSize(double size) {
        this.size = size;
    }

    public String getFormat() {
        return format;
    }
    public void setFormat(String format) {
        this.format = format;
    }

    @Override
    public String toString() {
        return author + " " + size + "Kb. " + format;
    }
}
