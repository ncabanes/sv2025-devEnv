public class Sprite {
    protected int x, y;
    public void dibujar() {
        // ...
    }
}
