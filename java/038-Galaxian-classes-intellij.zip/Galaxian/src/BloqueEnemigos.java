public class BloqueEnemigos {
    private Enemigo[] enemigos;

    public void mover() { }
}
