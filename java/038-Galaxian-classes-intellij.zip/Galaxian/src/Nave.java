public class Nave extends Sprite {

    protected int vidas;

    public void moverDerecha() { }
    public void moverIzquierda() { }
    public void disparar() { }
}
