public class Nivel {
    private int numero;
    private BloqueEnemigos bloque;
    private Nave nave;
    private Marcador marcador;

    public void avanzar() { }
}
