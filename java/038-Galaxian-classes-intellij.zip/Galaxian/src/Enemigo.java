public class Enemigo extends Sprite {

    public void mover() { }
    public void atacar() { }
    public void disparar() { }
}