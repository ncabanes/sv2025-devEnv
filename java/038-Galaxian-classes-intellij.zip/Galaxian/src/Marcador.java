public class Marcador {
    private int puntos;

    public void mostrar() { }
    public void incrementarPuntos() { }
}
