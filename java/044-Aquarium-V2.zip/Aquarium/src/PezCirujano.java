public class PezCirujano extends Pez {

    public PezCirujano(int x, int y) {
        super(x, y, "azul");
    }

    @Override
    public void dibujar() {
        System.out.println("Soy un pez cirujano.");
        super.dibujar();
    }

}
