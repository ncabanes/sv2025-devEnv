public class BancoPeces {
    private Pez[] peces;

    public void animar() {
        // ...
    }

    public void dibujar() {
        // ...
    }
}
