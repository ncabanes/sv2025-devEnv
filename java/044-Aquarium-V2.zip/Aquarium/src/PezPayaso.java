public class PezPayaso extends Pez {

    public PezPayaso(int x, int y) {
        super(x, y, "naranja");
    }

    @Override
    public void dibujar() {
        System.out.println("Soy un pez payaso.");
        super.dibujar();
    }
}
