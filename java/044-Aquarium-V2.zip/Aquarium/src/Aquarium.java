import java.util.Scanner;

class Aquarium {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Pez[] peces = new Pez[3];
        peces[0] = new PezBetta(20, 3);
        peces[1] = new PezCirujano(15, 6);
        peces[2] = new PezPayaso(40, 11);

        Planta pl = new Planta(30);
        Roca r = new Roca(15);

        boolean terminado = false;
        while (!terminado) {
            for (Pez p : peces) {
                p.animar();
            }
            pl.animar();
            r.animar();

            for (Pez p : peces) {
                p.dibujar();
            }
            pl.dibujar();
            r.dibujar();

            sc.nextLine();
        }
    }
}