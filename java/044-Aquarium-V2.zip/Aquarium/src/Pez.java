public abstract class Pez extends Sprite {
    private String color;

    public Pez(int x, int y, String color) {
        super(x, y);
        this.color = color;
    }

    @Override
    public void animar() {
        x++;
    }

    @Override
    public void dibujar() {
        System.out.println("Estoy nadando en "+x+","+y);
    }
}
