public class PezBetta extends Pez {

    public PezBetta(int x, int y) {
        super(x, y, "negro");
    }

    @Override
    public void dibujar() {
        System.out.println("Soy un betta.");
        super.dibujar();
    }
}
