public class Roca extends Sprite {

    public Roca(int x) {
        super(x, 0);
    }

    @Override
    public void animar() {
        y = 0;
    }

    @Override
    public void dibujar() {
        System.out.println("Soy una roca");
    }
}
