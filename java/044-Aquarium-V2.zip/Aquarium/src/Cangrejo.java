public class Cangrejo extends Sprite {

    public Cangrejo(int x) {
        super(x, 0);
    }

    @Override
    public void animar() {
        x ++;
        if (x % 5 == 0)
            cazar();
    }

    @Override
    public void dibujar() {
        System.out.println("Soy un cangrejo");
    }

    private void cazar() {
        System.out.println("Estoy cazando");
    }


}
