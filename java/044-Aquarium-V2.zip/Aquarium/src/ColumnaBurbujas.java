public class ColumnaBurbujas extends Sprite {
    public ColumnaBurbujas()
    {
        super(10,0);
    }

    @Override
    public void animar() {

    }

    @Override
    public void dibujar() {
        System.out.println("o");
    }
}
