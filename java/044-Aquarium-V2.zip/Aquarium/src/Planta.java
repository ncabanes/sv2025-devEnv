public class Planta extends Sprite {

    public Planta(int x) {
        super(x, 0);
    }

    @Override
    public void dibujar() {
        System.out.println("Swooooosh");
    }

    @Override
    public void animar() {
        // No se mueve, sorry
    }
}
