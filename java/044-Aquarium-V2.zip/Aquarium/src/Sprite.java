public abstract class Sprite {
    protected int x;
    protected int y;

    public Sprite(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public abstract void animar();
    public abstract void dibujar();
}
